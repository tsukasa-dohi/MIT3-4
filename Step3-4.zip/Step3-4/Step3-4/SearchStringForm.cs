﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Step3_4
{
    public partial class SearchStringForm : Form
    {
        // DLLを読み込む
        [DllImport("Step3-4Dll.dll", CallingConvention = CallingConvention.Cdecl)]
        private extern static void SearchStringInFolder(string searchTxt, string searchPath, string outputPath);

        public SearchStringForm()
        {
            InitializeComponent();
        }

        private void SearchFolderPathBtn_Click(object sender, EventArgs e)
        {
            //検索フォルダ選択ダイアログインスタンス生成
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                SearchFolderPathTxtBx.Text = fbd.SelectedPath;
            }
        }

        private void OutputFilePathBtn_Click(object sender, EventArgs e)
        {
            //出力ファイル選択ダイアログインスタンス生成
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "txt files (*.txt)|*.txt";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                OutputFilePathTxtBx.Text = sfd.FileName;
            }
        }

        private void StartBtn_Click(object sender, EventArgs e)
        {
            string searchTxt = SearchStringTxtBx.Text;

            string searchPath = SearchFolderPathTxtBx.Text + "\\";

            string outputPath = OutputFilePathTxtBx.Text;


            //計測用インスタンス生成
            var stopwatch = new System.Diagnostics.Stopwatch();
            // 計測開始
            stopwatch.Start();

            SearchStringInFolder(searchTxt, searchPath, outputPath);

            //計測終了
            stopwatch.Stop();
           
            //出力完了メッセージ
            MessageBox.Show("検索結果を出力しました。" + Environment.NewLine +
                "時間：" + stopwatch.ElapsedMilliseconds + "ミリ秒",
                "検索完了",
                MessageBoxButtons.OK);
        }
    }
}
