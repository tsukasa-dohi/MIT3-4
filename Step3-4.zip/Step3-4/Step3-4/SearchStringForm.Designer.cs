﻿namespace Step3_4
{
    partial class SearchStringForm
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SearchFolderPathTxtBx = new System.Windows.Forms.TextBox();
            this.SearchStringTxtBx = new System.Windows.Forms.TextBox();
            this.OutputFilePathTxtBx = new System.Windows.Forms.TextBox();
            this.SearchFolderPathBtn = new System.Windows.Forms.Button();
            this.OutputFilePathBtn = new System.Windows.Forms.Button();
            this.StartBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "検索フォルダ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "検索文字列";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "出力ファイル";
            // 
            // SearchFolderPathTxtBx
            // 
            this.SearchFolderPathTxtBx.Location = new System.Drawing.Point(82, 73);
            this.SearchFolderPathTxtBx.Name = "SearchFolderPathTxtBx";
            this.SearchFolderPathTxtBx.Size = new System.Drawing.Size(361, 19);
            this.SearchFolderPathTxtBx.TabIndex = 3;
            // 
            // SearchStringTxtBx
            // 
            this.SearchStringTxtBx.Location = new System.Drawing.Point(82, 119);
            this.SearchStringTxtBx.Name = "SearchStringTxtBx";
            this.SearchStringTxtBx.Size = new System.Drawing.Size(179, 19);
            this.SearchStringTxtBx.TabIndex = 4;
            // 
            // OutputFilePathTxtBx
            // 
            this.OutputFilePathTxtBx.Location = new System.Drawing.Point(82, 165);
            this.OutputFilePathTxtBx.Name = "OutputFilePathTxtBx";
            this.OutputFilePathTxtBx.Size = new System.Drawing.Size(361, 19);
            this.OutputFilePathTxtBx.TabIndex = 5;
            // 
            // SearchFolderPathBtn
            // 
            this.SearchFolderPathBtn.Location = new System.Drawing.Point(445, 72);
            this.SearchFolderPathBtn.Name = "SearchFolderPathBtn";
            this.SearchFolderPathBtn.Size = new System.Drawing.Size(19, 19);
            this.SearchFolderPathBtn.TabIndex = 6;
            this.SearchFolderPathBtn.Text = "...";
            this.SearchFolderPathBtn.UseVisualStyleBackColor = true;
            this.SearchFolderPathBtn.Click += new System.EventHandler(this.SearchFolderPathBtn_Click);
            // 
            // OutputFilePathBtn
            // 
            this.OutputFilePathBtn.Location = new System.Drawing.Point(445, 165);
            this.OutputFilePathBtn.Name = "OutputFilePathBtn";
            this.OutputFilePathBtn.Size = new System.Drawing.Size(19, 19);
            this.OutputFilePathBtn.TabIndex = 7;
            this.OutputFilePathBtn.Text = "...";
            this.OutputFilePathBtn.UseVisualStyleBackColor = true;
            this.OutputFilePathBtn.Click += new System.EventHandler(this.OutputFilePathBtn_Click);
            // 
            // StartBtn
            // 
            this.StartBtn.Location = new System.Drawing.Point(426, 206);
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.Size = new System.Drawing.Size(85, 43);
            this.StartBtn.TabIndex = 8;
            this.StartBtn.Text = "実行(&E)";
            this.StartBtn.UseVisualStyleBackColor = true;
            this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
            // 
            // SearchStringForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 261);
            this.Controls.Add(this.StartBtn);
            this.Controls.Add(this.OutputFilePathBtn);
            this.Controls.Add(this.SearchFolderPathBtn);
            this.Controls.Add(this.OutputFilePathTxtBx);
            this.Controls.Add(this.SearchStringTxtBx);
            this.Controls.Add(this.SearchFolderPathTxtBx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "SearchStringForm";
            this.Text = "文字列検索";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox SearchFolderPathTxtBx;
        private System.Windows.Forms.TextBox SearchStringTxtBx;
        private System.Windows.Forms.TextBox OutputFilePathTxtBx;
        private System.Windows.Forms.Button SearchFolderPathBtn;
        private System.Windows.Forms.Button OutputFilePathBtn;
        private System.Windows.Forms.Button StartBtn;
    }
}

